#! /bin/bash
docker build -t combinelab/salmon:0.9.0 .
