#! /bin/bash
docker build -t combinelab/salmon:0.10.2 .
